package com.svb.employee.controller;

import java.time.LocalTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.svb.employee.model.Employee;

import io.github.resilience4j.bulkhead.annotation.Bulkhead;

@RestController
public class EmployeeRegistrationController {

	Logger logger = LoggerFactory.getLogger(EmployeeRegistrationController.class);

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/register/employee")
	@Bulkhead(name = "bulkheadService1", fallbackMethod = "bulkHeadFallback",type = Bulkhead.Type.SEMAPHORE)
	public ResponseEntity<String> addEmployee() {
		Employee employee = new Employee();
		employee.setFirstName("Satish");
		employee.setLastName("Keshri");
		employee.setEmailId("sk@gmail.com");
		String response = restTemplate.postForObject("/addEmployee", employee, String.class);
		logger.info(LocalTime.now() + " Call processing finished = " + Thread.currentThread().getName());
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	public ResponseEntity<String> bulkHeadFallback(Exception t) {
		return new ResponseEntity<String>("EmployeeService is full and does not permit further calls",
				HttpStatus.TOO_MANY_REQUESTS);
	}
}