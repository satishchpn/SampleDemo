package com.svb.employee;
// Java program to demonstrate working of 
// IntStream parallel() on a given range 
import java.util.*; 
import java.util.stream.IntStream; 

class GFG { 

	// Driver code 
	public static void main(String[] args) 
	{ 

		// Creating a stream of integers 
		IntStream stream = IntStream.range(0, 10); 

		
		stream.parallel().forEach(System.out::println); 
		System.out.println("The corresponding " + 
				"parallel IntStream is :"); 
	} 
} 
