package com.svb.employee;

import java.util.stream.IntStream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class EmployeeManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagmentApplication.class, args);

		IntStream.range(0, 10).parallel().forEach(t -> {
			new RestTemplate().getForObject("http://localhost:8081/register/employee", String.class);

		});

	}

}
