package com.svb.employee.exception;

public class AppException extends Exception {

	private static final long serialVersionUID = -2904887578113019354L;

	public AppException(String msg) {
		super(msg);
	}
}