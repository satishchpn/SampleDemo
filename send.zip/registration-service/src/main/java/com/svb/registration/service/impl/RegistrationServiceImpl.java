package com.svb.registration.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.svb.registration.model.Employee;
import com.svb.registration.repository.RegistrationRepository;
import com.svb.registration.service.RegistrationService;

@Service
public class RegistrationServiceImpl implements RegistrationService {

	private static final Logger logger = LoggerFactory.getLogger(RegistrationServiceImpl.class);

	private RegistrationRepository registrationRepository;

	public RegistrationServiceImpl(RegistrationRepository registrationRepository) {
		this.registrationRepository = registrationRepository;
	}

	@Override
	public String addEmployee(@RequestBody Employee employee) throws InterruptedException {
		employee.setId(getEmployeeList().size() + 1);
		boolean isEmployeeAdded = registrationRepository.addEmployee(employee);
		String message;
		if (isEmployeeAdded) {
			message = "Registration successful. Your registration id is - '" + employee.getId()
					+ "'\n Save it for future communication with us.";

		} else {
			message = "There was some problem in registering the Employee. Please try after some time!!";

		}
		// logger.info("Add Employee status - {} and message - {}", isEmployeeAdded,
		// message);
		return message;
	}

	public List<Employee> getEmployeeList() {
		List<Employee> employeeList = registrationRepository.getEmployeeList();
		// logger.info("Fetching Employee list. Total Employee - {}",
		// employeeList.size());
		return employeeList;
	}
}