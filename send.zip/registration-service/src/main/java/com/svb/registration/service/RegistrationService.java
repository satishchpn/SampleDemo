package com.svb.registration.service;

import com.svb.registration.model.Employee;

public interface RegistrationService {

	String addEmployee(Employee employee) throws InterruptedException;

}