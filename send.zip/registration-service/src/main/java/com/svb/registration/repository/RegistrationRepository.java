package com.svb.registration.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.svb.registration.model.Employee;

@Repository
public class RegistrationRepository {

	List<Employee> employeeList = new ArrayList<>();

	public boolean addEmployee(Employee employee) {

		return employeeList.add(employee);
	}

	public List<Employee> getEmployeeList() {
		return employeeList;
	}
}