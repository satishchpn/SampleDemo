1> Start Zookeeper Server
2> Start Kafka Server
3> Start Kafka Consumer Console to See Message 
4> Call Producer API to publish message to Kafka Server
	http://localhost:9090/api/publish
	