package com.svb.paymenthub.phubmtproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PHubMtProducerApplicationTest {

	@Test
	void contextLoads() {
	}

}
