package com.svb.paymenthub.phubmtproducer.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.svb.paymenthub.phubmtproducer.model.MTTestMessage;
import com.svb.paymenthub.phubmtproducer.service.MTProducerService;

import lombok.extern.slf4j.Slf4j;

@RestController
@EnableBinding(Source.class)
@Slf4j
public class MTProducerController {

	@Autowired
	MTProducerService service;

	@PostMapping("/api/publish")
	public ResponseEntity<String> sendMessage(@RequestBody MTTestMessage message) {
		log.info("Publishing Book..");
		message.setMessageUUID("MT101" + String.valueOf(new Random().nextInt()));
		service.handleMTMessage(message);
		return ResponseEntity.ok("MTMessage with id : " + message.getMessageUUID() + " Sent Successfully to Kafka");
	}
}
