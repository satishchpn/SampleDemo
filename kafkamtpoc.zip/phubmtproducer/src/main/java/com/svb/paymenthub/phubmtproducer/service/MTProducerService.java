package com.svb.paymenthub.phubmtproducer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.svb.paymenthub.phubmtproducer.model.MTTestMessage;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MTProducerService {

	@Autowired
	MessageChannel output;

	public void handleMTMessage(MTTestMessage data) {
		log.info("Sending MT message to kafka : " + data);
		Message<MTTestMessage> message = MessageBuilder.withPayload(data).setHeader("Haeder1", "SomeHeader1").build();
		output.send(message);
		log.info("MTMessage sent successfully to kafka");
	}

}
