package com.svb.paymenthub.phubmtpublisher.exception;

public class PublisherServiceException extends RuntimeException {

	private static final long serialVersionUID = 7227047058974623793L;

	public PublisherServiceException() {
		super();
	}

	public PublisherServiceException(String message) {
		super(message);
	}

	public PublisherServiceException(Throwable cause) {
		super(cause);
	}

	public PublisherServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public PublisherServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
