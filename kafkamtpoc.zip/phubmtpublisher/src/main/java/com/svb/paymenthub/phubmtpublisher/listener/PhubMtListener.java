
package com.svb.paymenthub.phubmtpublisher.listener;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.Message;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.Gson;
import com.svb.paymenthub.phubmtpublisher.channel.MessageChannel;
import com.svb.paymenthub.phubmtpublisher.exception.PublisherServiceException;
import com.svb.paymenthub.phubmtpublisher.model.MTTestMessage;

import lombok.extern.slf4j.Slf4j;

@EnableBinding({ MessageChannel.class })
@Slf4j
public class PhubMtListener {

	@StreamListener(MessageChannel.INPUT)
	public void handleMessage(Message<?> message) throws JsonMappingException, JsonProcessingException {
		processMessage(message);
	}

	private void processMessage(Message<?> message) throws JsonMappingException, JsonProcessingException {
		log.info("Message Received :" + message.toString());
		MTTestMessage packet = new Gson().fromJson(message.getPayload().toString(), MTTestMessage.class);
		String messageType = packet.getMessageType();
		if (!("Java".equals(messageType))) {
			throw new PublisherServiceException("Error Occured While Processing MT Message");
		}

	}

	/*
	 * @StreamListener("errorChannel")
	 * 
	 * @SendTo("myErrors") public Message<?> handleError(ErrorMessage message) {
	 * log.info("Handling Error..."); log.info("Paylod :" +
	 * message.getPayload().toString()); log.info("Headers :" +
	 * message.getHeaders().toString()); return message; }
	 */

}
