package com.svb.paymenthub.phubmtpublisher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhubMtPublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhubMtPublisherApplication.class, args);
	}

}
