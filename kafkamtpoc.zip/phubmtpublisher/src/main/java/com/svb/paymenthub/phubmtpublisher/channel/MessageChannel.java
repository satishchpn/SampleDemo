package com.svb.paymenthub.phubmtpublisher.channel;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface MessageChannel {

	String INPUT = "input";

	@Input
	SubscribableChannel input();

}
